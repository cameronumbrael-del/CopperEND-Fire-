package it.crystalnest.copper_fire;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;

public final class ModLoader implements ModInitializer {
  private static final Identifier TRIAL_DISPENSER = Identifier.withDefaultNamespace("dispensers/trial_chambers/chamber");

  @Override
  public void onInitialize() {
    FireRegistry.register();

    // Campfires go right after the vanilla campfire; charges right after the vanilla fire charge. No new tab.
    CreativeModeTabEvents.MODIFY_OUTPUT_ALL.register((tab, output) ->
      BuiltInRegistries.CREATIVE_MODE_TAB.getResourceKey(tab).ifPresent(key -> {
        if (key == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
          output.insertAfter(Items.CAMPFIRE, FireRegistry.COPPER_CAMPFIRE_ITEM, FireRegistry.END_CAMPFIRE_ITEM);
        } else if (key == CreativeModeTabs.INGREDIENTS || key == CreativeModeTabs.TOOLS_AND_UTILITIES) {
          output.insertAfter(Items.FIRE_CHARGE, FireRegistry.COPPER_FIRE_CHARGE, FireRegistry.END_FIRE_CHARGE);
        }
      })
    );

    // Same trial chamber dispenser drop the original had for the copper charge; the end charge joins it.
    LootTableEvents.MODIFY.register((key, builder, source, registries) -> {
      if (key.identifier().equals(TRIAL_DISPENSER)) {
        builder.modifyPools(pool -> {
          pool.add(LootItem.lootTableItem(FireRegistry.COPPER_FIRE_CHARGE).setWeight(3).apply(SetItemCountFunction.setCount(UniformGenerator.between(4.0F, 8.0F))));
          pool.add(LootItem.lootTableItem(FireRegistry.END_FIRE_CHARGE).setWeight(1).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 4.0F))));
        });
      }
    });
  }
}
