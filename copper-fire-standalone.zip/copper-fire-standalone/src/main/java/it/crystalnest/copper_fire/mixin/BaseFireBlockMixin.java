package it.crystalnest.copper_fire.mixin;

import it.crystalnest.copper_fire.FireRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Used by flint and steel, dispensers and vanilla fire charges to choose which fire to place.
 * End stone gives End Fire; copper blocks give Copper Fire.
 */
@Mixin(BaseFireBlock.class)
public abstract class BaseFireBlockMixin {
  @Inject(method = "getState", at = @At("HEAD"), cancellable = true)
  private static void copperFire$getState(BlockGetter level, BlockPos pos, CallbackInfoReturnable<BlockState> cir) {
    Block fire = FireRegistry.fireFor(level.getBlockState(pos.below()));
    if (fire != null) {
      cir.setReturnValue(fire.defaultBlockState());
    }
  }
}
