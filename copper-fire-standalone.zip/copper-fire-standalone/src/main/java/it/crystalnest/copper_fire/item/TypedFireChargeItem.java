package it.crystalnest.copper_fire.item;

import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.CandleBlock;
import net.minecraft.world.level.block.CandleCakeBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.gameevent.GameEvent;

/** Fire charge that always places a specific fire block, whatever block it is used on. */
public class TypedFireChargeItem extends Item {
  private final Supplier<? extends Block> fire;

  public TypedFireChargeItem(Properties properties, Supplier<? extends Block> fire) {
    super(properties);
    this.fire = fire;
  }

  @Override
  public InteractionResult useOn(UseOnContext context) {
    Level level = context.getLevel();
    BlockPos pos = context.getClickedPos();
    BlockState state = level.getBlockState(pos);
    boolean used = false;
    if (!CampfireBlock.canLight(state) && !CandleBlock.canLight(state) && !CandleCakeBlock.canLight(state)) {
      pos = pos.relative(context.getClickedFace());
      if (level.getBlockState(pos).isAir()) {
        BlockState fireState = this.fire.get().defaultBlockState();
        if (fireState.canSurvive(level, pos)) {
          this.playSound(level, pos);
          level.setBlockAndUpdate(pos, fireState);
          level.gameEvent(context.getPlayer(), GameEvent.BLOCK_PLACE, pos);
          used = true;
        }
      }
    } else {
      this.playSound(level, pos);
      level.setBlockAndUpdate(pos, state.setValue(BlockStateProperties.LIT, true));
      level.gameEvent(context.getPlayer(), GameEvent.BLOCK_CHANGE, pos);
      used = true;
    }
    if (used) {
      context.getItemInHand().shrink(1);
      return InteractionResult.SUCCESS;
    }
    return InteractionResult.FAIL;
  }

  private void playSound(Level level, BlockPos pos) {
    level.playSound(null, pos, SoundEvents.FIRECHARGE_USE, SoundSource.BLOCKS, 1.0F, (level.getRandom().nextFloat() - level.getRandom().nextFloat()) * 0.2F + 1.0F);
  }
}
