package it.crystalnest.copper_fire;

import it.crystalnest.copper_fire.block.CopperFireBlock;
import it.crystalnest.copper_fire.block.EndFireBlock;
import it.crystalnest.copper_fire.item.TypedFireChargeItem;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;

/**
 * Everything is registered in the minecraft namespace, exactly like the original mod did,
 * so existing worlds that contain copper fire / copper campfires keep working.
 */
public final class FireRegistry {
  public static final TagKey<Block> COPPER_FIRE_BASE_BLOCKS = TagKey.create(Registries.BLOCK, id("copper_fire_base_blocks"));
  public static final TagKey<Block> END_FIRE_BASE_BLOCKS = TagKey.create(Registries.BLOCK, id("end_fire_base_blocks"));

  public static final Block COPPER_FIRE = registerBlock("copper_fire", key -> new CopperFireBlock(fireProperties(key, MapColor.COLOR_GREEN)));
  public static final Block END_FIRE = registerBlock("end_fire", key -> new EndFireBlock(fireProperties(key, MapColor.COLOR_PURPLE)));

  public static final Block COPPER_CAMPFIRE = registerBlock("copper_campfire", key -> new CampfireBlock(false, 1, campfireProperties(key)));
  public static final Block END_CAMPFIRE = registerBlock("end_campfire", key -> new CampfireBlock(false, 1, campfireProperties(key)));

  public static final Item COPPER_CAMPFIRE_ITEM = registerItem("copper_campfire", key -> new BlockItem(COPPER_CAMPFIRE, new Item.Properties().setId(key).useBlockDescriptionPrefix()));
  public static final Item END_CAMPFIRE_ITEM = registerItem("end_campfire", key -> new BlockItem(END_CAMPFIRE, new Item.Properties().setId(key).useBlockDescriptionPrefix()));
  public static final Item COPPER_FIRE_CHARGE = registerItem("copper_fire_charge", key -> new TypedFireChargeItem(new Item.Properties().setId(key), () -> COPPER_FIRE));
  public static final Item END_FIRE_CHARGE = registerItem("end_fire_charge", key -> new TypedFireChargeItem(new Item.Properties().setId(key), () -> END_FIRE));

  private FireRegistry() {}

  /** Touch this class so the static initializers run, then let the vanilla campfire block entity accept the new campfires. */
  public static void register() {
    BlockEntityType.CAMPFIRE.addSupportedBlock(COPPER_CAMPFIRE);
    BlockEntityType.CAMPFIRE.addSupportedBlock(END_CAMPFIRE);
  }

  /** Fire placed by flint and steel etc: returns the matching permanent fire for the block below, or null. */
  public static Block fireFor(net.minecraft.world.level.block.state.BlockState below) {
    if (below.is(END_FIRE_BASE_BLOCKS)) {
      return END_FIRE;
    }
    if (below.is(COPPER_FIRE_BASE_BLOCKS)) {
      return COPPER_FIRE;
    }
    return null;
  }

  private static Identifier id(String path) {
    return Identifier.withDefaultNamespace(path);
  }

  private static BlockBehaviour.Properties fireProperties(ResourceKey<Block> key, MapColor color) {
    return BlockBehaviour.Properties.of()
      .setId(key)
      .mapColor(color)
      .replaceable()
      .noCollision()
      .instabreak()
      .lightLevel(state -> 14)
      .sound(SoundType.WOOL)
      .pushReaction(PushReaction.DESTROY);
  }

  private static BlockBehaviour.Properties campfireProperties(ResourceKey<Block> key) {
    return BlockBehaviour.Properties.of()
      .setId(key)
      .mapColor(MapColor.PODZOL)
      .strength(2.0F)
      .sound(SoundType.WOOD)
      .lightLevel(state -> state.getValue(BlockStateProperties.LIT) ? 14 : 0)
      .noOcclusion();
  }

  private static Block registerBlock(String name, java.util.function.Function<ResourceKey<Block>, Block> factory) {
    ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, id(name));
    return Registry.register(BuiltInRegistries.BLOCK, key, factory.apply(key));
  }

  private static Item registerItem(String name, java.util.function.Function<ResourceKey<Item>, Item> factory) {
    ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(name));
    return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(key));
  }
}
