package it.crystalnest.copper_fire.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.BaseFireBlock;

public class CopperFireBlock extends PermanentFireBlock {
  public static final MapCodec<CopperFireBlock> CODEC = simpleCodec(CopperFireBlock::new);

  public CopperFireBlock(Properties properties) {
    super(properties, 1.5F);
  }

  @Override
  protected MapCodec<? extends BaseFireBlock> codec() {
    return CODEC;
  }
}
