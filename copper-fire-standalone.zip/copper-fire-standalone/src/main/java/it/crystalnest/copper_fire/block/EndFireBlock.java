package it.crystalnest.copper_fire.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.BaseFireBlock;

public class EndFireBlock extends PermanentFireBlock {
  public static final MapCodec<EndFireBlock> CODEC = simpleCodec(EndFireBlock::new);

  public EndFireBlock(Properties properties) {
    super(properties, 1.5F);
  }

  @Override
  protected MapCodec<? extends BaseFireBlock> codec() {
    return CODEC;
  }
}
