package it.crystalnest.copper_fire;

public final class Constants {
  public static final String MOD_ID = "copper_fire";

  private Constants() {}
}
