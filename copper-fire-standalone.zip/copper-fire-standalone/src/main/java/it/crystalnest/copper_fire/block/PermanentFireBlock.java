package it.crystalnest.copper_fire.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * A fire that, like soul fire, never ages, spreads, or burns out. It has no random tick, so rain
 * can't put it out either. It still disappears if the block under it is removed, or when punched.
 */
public abstract class PermanentFireBlock extends BaseFireBlock {
  protected PermanentFireBlock(Properties properties, float damage) {
    super(properties, damage);
  }

  @Override
  protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
    BlockPos below = pos.below();
    return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
  }

  @Override
  protected BlockState updateShape(BlockState state, LevelReader level, ScheduledTickAccess ticks, BlockPos pos, Direction direction, BlockPos neighborPos, BlockState neighborState, RandomSource random) {
    return this.canSurvive(state, level, pos) ? this.defaultBlockState() : Blocks.AIR.defaultBlockState();
  }

  // No @Override on purpose: abstract in some versions, absent in others.
  protected boolean canBurn(BlockState state) {
    return true;
  }
}
