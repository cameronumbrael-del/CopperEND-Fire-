# Copper Fire (standalone, Minecraft 26.3)

Rebuilt from the compiled 26.2 jar, since no source was available. It has no Prometheus or Cobweb.
The only mod dependency left is Fabric API; Fabric mods cannot load their assets or data without it.

## Build
1. Open https://fabricmc.net/develop, pick 26.3, and copy the current loader and Fabric API versions into `gradle.properties`
   (`fabric_api_version` is a placeholder). Also check the Loom version in `build.gradle`.
2. `./gradlew build` (needs JDK 25). The jar is in `build/libs/`.

## What changed vs 1.1.1
- Copper lantern light no longer drops with oxidation (vanilla behaviour; the mixin is gone).
- New End Fire, End Campfire, End Fire Charge (electric purple recolors of the copper textures).
- Fire placed (flint and steel, dispenser) on end stone or end stone bricks becomes End Fire.
  Tag: `data/minecraft/tags/block/end_fire_base_blocks.json`. Copper uses `copper_fire_base_blocks`, as before.
- Copper Fire and End Fire never go out (no aging, no spreading, no rain). They are removed only by punching
  or by losing the block underneath.
- Charges place their own fire on any solid top face. Campfires and charges sit next to the vanilla ones in the creative tabs.
- Ids stay in the `minecraft:` namespace like the original, so existing copper fire/campfires keep working.

## Dropped (they depended on Prometheus)
- Copper Fire Aspect / Copper Flame enchantments and their datapack.
- Copper Golem fire-type, and the custom burning-entity overlay (entities burn as normal fire; the block deals 1.5 damage).

## Not compiled or tested
Written without access to the 26.3 sources. Likely spots to adjust if the build complains:
`CampfireBlock` constructor (fireDamage int/float), `BlockEntityType.addSupportedBlock` (Fabric API),
`BaseFireBlock.getState` mixin target, and the `updateShape` signature.
License: CNCLv1 allows private modification only; do not redistribute the compiled jar.
